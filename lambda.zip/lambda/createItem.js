const { connectToDatabase, models } = require('./mongodb');

exports.handler = async (event) => {
  try {
    await connectToDatabase();
    
    const { collection } = event.pathParameters;
    const Model = models[collection];
    
    if (!Model) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Coleção inválida' })
      };
    }

    const data = JSON.parse(event.body);
    const newItem = new Model(data);
    await newItem.save();
    
    return {
      statusCode: 201,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*'
      },
      body: JSON.stringify(newItem)
    };
  } catch (error) {
    console.error('Erro:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Erro interno do servidor' })
    };
  }
}; 